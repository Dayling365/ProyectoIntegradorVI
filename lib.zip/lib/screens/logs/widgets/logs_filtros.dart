import 'package:flutter/material.dart';

class LogsFiltros extends StatelessWidget {
  const LogsFiltros({super.key});

  @override
  Widget build(BuildContext context) {
    const Color primary = Color(0xFF1B2A5C);

    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 4),
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: _filtro(
                    Icons.calendar_today_outlined,
                    '01/10/2026',
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _filtro(
                    Icons.calendar_today_outlined,
                    '31/10/2026',
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            Row(
              children: [
                Expanded(
                  child: _filtro(
                    Icons.person_outline,
                    'Usuario',
                    subtitulo: 'Todos',
                    arrow: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _filtro(
                    Icons.grid_view_outlined,
                    'Módulo',
                    subtitulo: 'Todos',
                    arrow: true,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            Row(
              children: [
                Expanded(
                  child: _filtro(
                    Icons.shield_outlined,
                    'Estado',
                    subtitulo: 'Todos',
                    arrow: true,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _filtro(
                    Icons.access_time,
                    'Ordenar por',
                    subtitulo: 'Más recientes',
                    arrow: true,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 4),

            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {},
                child: const Text(
                  '×  Limpiar filtros',
                  style: TextStyle(
                    color: primary,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filtro(
    IconData icon,
    String texto, {
    String? subtitulo,
    bool arrow = false,
  }) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.grey.shade200,
        ),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            size: 17,
            color: const Color(0xFF1B2A5C),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: subtitulo == null
                ? Text(
                    texto,
                    style: const TextStyle(
                      color: Color(0xFF1B2A5C),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                : Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        texto,
                        style: const TextStyle(
                          color: Color(0xFF1B2A5C),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        subtitulo,
                        style: const TextStyle(
                          color: Color(0xFF8A94A6),
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
          ),
          if (arrow)
            const Icon(
              Icons.keyboard_arrow_down,
              size: 16,
              color: Color(0xFF8A94A6),
            ),
        ],
      ),
    );
  }
}